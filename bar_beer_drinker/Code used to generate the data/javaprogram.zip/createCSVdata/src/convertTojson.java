import java.lang.String;
import java.io.*;
import java.lang.reflect.Array;
import java.util.*;
import java.util.Random;
//Add a bought, quantity, sells, frequents, likes table
//Redo opening and closing hours
public class convertTojson {

    private static String txtFiles[] = {"names.txt", "beers.txt", "bars.txt", "menu.txt"};
    private static String csvFiles[] = {"names.csv", "beers.csv", "bars.csv", "menu.csv", "transaction.csv", "likes.csv",
                                        "sells.csv", "bill.csv", "frequents.csv"};
    //St = NYC
    //Rd = Boston
    //Pl = Chicago
    //Ave = Austin
    private static final String STREETNAMES[] = {"Madison Ave", "Monroe Pl", "Pike St", "Henry Rd", "Cherry St", "Canal Rd",
            "Hester St", "Mott Pl", "White Ave", "Grand St", "Broome Ave", "Kenmare Rd", "Stanton Pl", "Eldridge Ave",
            "Rivingston St", "Delancey St", "Allen St", "Laight Pl", "Hubert St", "Downing St", "Bleecker St", "Minetta Rd",
            "Morton Rd", "Carmine St", "Downing Rd", "Charlton Pl", "Vandam St", "King Ave", "Dominick St", "Sullivan Ave",
            "Grove Pl", "Commerce Rd", "Hudson St", "Washington St", "Jones Pl", "Leroy Rd", "Carmine St", "Barrow St",
            "Christopher St", "Pell Pl", "Elizabeth Ave", "Baxter Ave", "Battery Pl", "W Thames St", "Edgar Pl", "Rector St"}; //Length 46
    private static final String CITY[] = {"New York City", "Boston", "Chicago", "Austin"};
    private static final String CITYFILES[] = {"NYC.txt", "Boston.txt", "Chicago.txt", "Austin.txt"};
    private static final double NUMTAX[] = {.0625, .1025,.0625, .0882};

    private static final double BEERPRICE[] = {3.00, 4.00, 4.50, 5.00, 6.00, 6.50, 7.00, 7.50}; //8 prices

    private static final String FOOD[] = {"Cheeseburger", "French Fries", "Nachos", "Wings", "Quesadilla", "Onion Rings",
            "Tater Tots", "Mozoralla Sticks", "Potato Skins", "Pretzel"};
    private static final double PFOOD[] = {7.00, 2.00, 5.00, 6.50, 7.00, 2.00, 3.00, 5.00, 4.00, 4.50, 3.00};

    private static final String DRINKS[] = {"Coca Cola", "Sweet Tea", "Sprite", "Root Beer", "Club Soda"};
    private static final double PDRINKS[] = {2.50, 3.00, 2.50, 2.50, 2.00};

    private static String generateAddress(){
        Random rand = new Random();
        String address;
        int houseNum = rand.nextInt(600) + 1;
        int selectRanstreet = rand.nextInt(45) + 1;
        address = houseNum + " " + STREETNAMES[selectRanstreet];
        return address;
    }
    private static String generateNumaddress(){
        Random rand = new Random();
        String address, cardinalDirection;
        int storeNum = rand.nextInt(200) + 1;
        int westOreast = rand.nextInt(2);
        int streetNum = rand.nextInt(70) + 1;
        if(westOreast == 0)
            cardinalDirection = "East";
        else
            cardinalDirection = "West";
        address =  storeNum + " " + cardinalDirection + " " + streetNum + " street";
        return address;
    }
    private static String generatePhonenumber(){
        Random rand = new Random();
        int zipCoderandom = rand.nextInt(2);
        String phoneNumber = "212";

        while(phoneNumber.length() != 9){
            int restOfnum = rand.nextInt(10);
            phoneNumber = phoneNumber + restOfnum;
        }
        return phoneNumber;
    }
    private static String generateDate(){
        Random rand = new Random();
        int randMonth, randDay, randYear;
        randMonth = rand.nextInt(11) + 1;
        switch(randMonth){
            case 2:
                randDay = rand.nextInt(27) + 1;
                break;
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
                randDay = rand.nextInt(30) + 1;
                break;
            default:
                randDay = rand.nextInt(29) + 1;
        }
        randYear = rand.nextInt(2) + 2017;
        return String.valueOf(randMonth + "/" + randDay + "/" + randYear);
    }
    public static String generateTime(){
        Random rand = new Random();
        int hour, minute;
        hour = rand.nextInt(4) + 9;
        if(hour == 13)
            minute = rand.nextInt(1) + 29;
        else
            minute = rand.nextInt(1) + 58;
        return String.valueOf(hour) + String.valueOf(minute);
    }
    public static double TOTAL;
    //If time == 0 then opening
    //If time == 1 then closing
    private static String hoursTime(int whichTime){
        Random rand = new Random();
        String oTime[] = {"6:00pm", "6:30pm", "7:00pm", "7:30pm", "8:30pm", "9:00pm"},
                cTime[] = {"1:30am", "2:00am", "2:30am", "3:00am", "3:30am", "4:00am"};
        if(whichTime == 0){
            return oTime[rand.nextInt(6)];
        }
        else
            return cTime[rand.nextInt(6)];
    }
    private static String pickRandomname() throws IOException {
        Random rand = new Random();
        ArrayList<String> nameList = new ArrayList<>();
        File nameFile = new File("C:\\Users\\Vinh Huynh\\IdeaProjects\\createCSVdata\\src\\" + txtFiles[0]);
        BufferedReader buffer = new BufferedReader(new FileReader(nameFile));
        String line;
        while ((line = buffer.readLine()) != null)
            nameList.add(line);

        return nameList.get(rand.nextInt(4999));
    }

    private static String pickRandombeer() throws  IOException{
        Random rand = new Random();
        ArrayList<String> beerList = new ArrayList<>();
        File beerFile = new File("C:\\Users\\Vinh Huynh\\IdeaProjects\\createCSVdata\\src\\" + txtFiles[1]);
        BufferedReader buffer = new BufferedReader(new FileReader(beerFile));
        String line, currentLine[];
        while((line = buffer.readLine()) != null) {
            currentLine = line.split("-");
            //System.out.println("Adding: " + currentLine[0]);
            beerList.add(currentLine[0]);
        }

        return beerList.get(rand.nextInt(49));
    }

    public static void main(String[] args) throws IOException {
        File file = new File("C:\\Users\\Vinh Huynh\\IdeaProjects\\createCSVdata\\src\\" + txtFiles[0]);
        ArrayList<LinkedHashMap<String, String>> masterList = new ArrayList<>();

        BufferedReader buff  = new BufferedReader(new FileReader(file));
        PrintWriter pw = new PrintWriter(csvFiles[7]);
        pw.flush();
        String line;
        String currentLine[];

        while ((line = buff.readLine()) != null) {
            //LinkedHashMap<String, String> tempHash;// = new LinkedHashMap<>();
            //currentLine = line.split("-");
            //System.out.println("Current Line: " + currentLine[0]);
            //LinkedHashMap<String, String> tempHash = new LinkedHashMap<>();

            /*
            //For insertion of namesTXT
            String address = generateAddress();
            tempHash.put("Name", line);
            tempHash.put("Address", address);
            if(address.contains("St"))
                tempHash.put("City", CITY[0]); //NYC
            else if(address.contains("Rd"))
                tempHash.put("City", CITY[1]); //BOSTON
            else if(address.contains("Pl"))
                tempHash.put("City", CITY[2]); //Chicago
            else if(address.contains("Ave"))
                tempHash.put("City", CITY[3]); //Austin
            tempHash.put("PhoneNum", generatePhonenumber());
            */

            //For insertion of beerTXT
//            tempHash.put("Beer", currentLine[0]);
//            tempHash.put("Manf", currentLine[1]);

            //For insertion of the bar
//            Random rand = new Random();
//            tempHash.put("Name", line);
//            tempHash.put("Address", generateNumaddress());
//            tempHash.put("City", CITY[rand.nextInt(4)]);
//            tempHash.put("Opening", hoursTime(0));
//            tempHash.put("Closing", hoursTime(1));
//            tempHash.put("PhoneNum", generatePhonenumber());


            //For the likes table
            //Atmost they should like 5 beers
//            Random rand = new Random();
//            int numBeers = rand.nextInt(5), counter = 0;
//            while(counter < numBeers){
//                tempHash = new LinkedHashMap<>();
//                tempHash.put("Name", line);
//                tempHash.put("Beer", pickRandombeer());
//                masterList.add(tempHash);
//                counter++;
//            }
            //For Sells table
            //Sell min 5 beers
//            Random rand = new Random();
//            int sellBeers = rand.nextInt(10) + 5, sellFood = rand.nextInt(5), sellDrink = rand.nextInt(3), counter = 0;
//            while(counter != 1) {
//                LinkedHashMap<String, String> tempHash;
//                for (int i = 0; i < sellBeers; i++) {
//                    tempHash = new LinkedHashMap<>();
//                    tempHash.put("Bar", line);
//                    tempHash.put("Beer", pickRandombeer());
//                    tempHash.put("BPrice", String.valueOf(BEERPRICE[rand.nextInt(7)]));
//                    masterList.add(tempHash);
//                }
//                for(int i = 0; i < FOOD.length;i++){
//                    tempHash = new LinkedHashMap<>();
//                    tempHash.put("Bar", line);
//                    tempHash.put("Menu", FOOD[i]);
//                    tempHash.put("Price", String.valueOf(PFOOD[i]));
//                    masterList.add(tempHash);
//                }
//                for(int i = 0; i < DRINKS.length; i++){
//                    tempHash = new LinkedHashMap<>();
//                    tempHash.put("Bar", line);
//                    tempHash.put("Menu", DRINKS[i]);
//                    tempHash.put("Price", String.valueOf(PDRINKS[i]));
//                    masterList.add(tempHash);
//                }
//                counter++;
//            }


            //masterList.add(tempHash);
//            for(String i : tempHash.values())
//                System.out.println(i);
        }
//        FOR TRANSACTION
//        items, price, and transaction ID
//        Need a seperate Bill Table
//        int id = 0, beerOrfood, drinkOrfood, quantity;
//        while(id < 20000){
//            LinkedHashMap<String, String> tempHash = new LinkedHashMap<>();
//            //For insertion of transaction data
//            Random rand = new Random();
//            //0 for beer
//            //1 for food
//            beerOrfood = rand.nextInt(2);
//            drinkOrfood = rand.nextInt(2);
//            quantity = rand.nextInt(4) + 1;
//            tempHash.put("TransID", String.valueOf(id++));
//            if(beerOrfood == 0) {
//                int beer = rand.nextInt(8);
//                tempHash.put("Item", pickRandombeer());
//                tempHash.put("Price", String.valueOf(BEERPRICE[beer]));//CHANGE TO STAY CONSISTANT
//                tempHash.put("Quantity", String.valueOf(quantity));
//            }
//            else{
//                if(drinkOrfood == 0){
//                    int food = rand.nextInt(10);
//                    tempHash.put("Item", String.valueOf(FOOD[food]));
//                    tempHash.put("Price", String.valueOf(PFOOD[food]));
//                    tempHash.put("Quantity", String.valueOf(quantity));
//                }
//                else{
//                    int drink = rand.nextInt(5);
//                    tempHash.put("Item", String.valueOf(DRINKS[drink]));
//                    tempHash.put("Price", String.valueOf(PDRINKS[drink]));
//                    tempHash.put("Quantity", String.valueOf(quantity));
//                }
//            }
//            masterList.add(tempHash);
//        }

//        For creating the bill table
//        Columns: bill_id,drinker, time, tax, list_of transactions, and quantity
//        String cityLine, namesCity[] = {"namesNYC.csv", "namesBoston.csv", "namesChicago.csv", "namesAustin.csv"}, lineReg[], nameCell[];
//        ArrayList<String> nyc = new ArrayList<>();
//        File cityFile = new File("C:\\Users\\Vinh Huynh\\IdeaProjects\\createCSVdata\\src\\" + CITYFILES[0]);
//        BufferedReader cityBuff = new BufferedReader(new FileReader(cityFile));
//        while((cityLine = cityBuff.readLine()) != null)
//            nyc.add(cityLine);
//        ArrayList<String> nameNYC = new ArrayList<>();
//        cityFile = new File("C:\\Users\\Vinh Huynh\\IdeaProjects\\createCSVdata\\src\\" + namesCity[0]);
//        cityBuff = new BufferedReader(new FileReader(cityFile));
//        while((cityLine = cityBuff.readLine()) != null) {
//            lineReg = cityLine.split(",");
//            nameCell = lineReg[0].split("=");
//            nameNYC.add(nameCell[1]);
//        }
//
//        ArrayList<String> boston = new ArrayList<>();
//        cityFile = new File("C:\\Users\\Vinh Huynh\\IdeaProjects\\createCSVdata\\src\\" + CITYFILES[1]);
//        cityBuff = new BufferedReader(new FileReader(cityFile));
//        while((cityLine = cityBuff.readLine()) != null)
//            boston.add(cityLine);
//        ArrayList<String> nameBoston = new ArrayList<>();
//        cityFile = new File("C:\\Users\\Vinh Huynh\\IdeaProjects\\createCSVdata\\src\\" + namesCity[1]);
//        cityBuff = new BufferedReader(new FileReader(cityFile));
//        while((cityLine = cityBuff.readLine()) != null) {
//            lineReg = cityLine.split(",");
//            nameCell = lineReg[0].split("=");
//            nameBoston.add(nameCell[1]);
//        }
//
//        ArrayList<String> chicago = new ArrayList<>();
//        cityFile = new File("C:\\Users\\Vinh Huynh\\IdeaProjects\\createCSVdata\\src\\" + CITYFILES[2]);
//        cityBuff = new BufferedReader(new FileReader(cityFile));
//        while((cityLine = cityBuff.readLine()) != null)
//            chicago.add(cityLine);
//        ArrayList<String> nameChicago = new ArrayList<>();
//        cityFile = new File("C:\\Users\\Vinh Huynh\\IdeaProjects\\createCSVdata\\src\\" + namesCity[2]);
//        cityBuff = new BufferedReader(new FileReader(cityFile));
//        while((cityLine = cityBuff.readLine()) != null) {
//            lineReg = cityLine.split(",");
//            nameCell = lineReg[0].split("=");
//            nameChicago.add(nameCell[1]);
//        }
//
//        ArrayList<String> austin = new ArrayList<>();
//        cityFile = new File("C:\\Users\\Vinh Huynh\\IdeaProjects\\createCSVdata\\src\\" + CITYFILES[3]);
//        cityBuff = new BufferedReader(new FileReader(cityFile));
//        while((cityLine = cityBuff.readLine()) != null)
//            austin.add(cityLine);
//        ArrayList<String> nameAustin = new ArrayList<>();
//        cityFile = new File("C:\\Users\\Vinh Huynh\\IdeaProjects\\createCSVdata\\src\\" + namesCity[3]);
//        cityBuff = new BufferedReader(new FileReader(cityFile));
//        while((cityLine = cityBuff.readLine()) != null) {
//            lineReg = cityLine.split(",");
//            nameCell = lineReg[0].split("=");
//            nameAustin.add(nameCell[1]);
//        }
//
//        File transactionData = new File("C:\\Users\\Vinh Huynh\\IdeaProjects\\createCSVdata\\src\\transaction.csv");
//        BufferedReader buffer = new BufferedReader(new FileReader(transactionData));
//
//        File namesFile = new File("C:\\Users\\Vinh Huynh\\IdeaProjects\\createCSVdata\\src\\names.txt");
//        BufferedReader nameBuff  = new BufferedReader(new FileReader(namesFile));
//        Queue<String> nameStack = new LinkedList<>();
//        String nameline;
//        while((nameline = nameBuff.readLine()) != null)
//            nameStack.add(nameline);
//
//        int billID = 1, numTransactions, counter = 0;
//        String cellOne[], cellTwo[];
//        int nycLen = nyc.size(), bostonLen = boston.size(), chicagoLen = chicago.size(), austinLen = austin.size();
//        Random rand = new Random();
//        numTransactions = rand.nextInt(5) + 1;
//        String bar, date = generateDate();
//        while((line = buffer.readLine()) != null){
//            LinkedHashMap<String, String> tempHash = new LinkedHashMap<>();
//            currentLine = line.split(",");
//            String name = nameStack.peek();
//            if(nameNYC.contains(name))
//                bar = nyc.get(rand.nextInt(nycLen));
//            else if(nameBoston.contains(name))
//                bar = boston.get(rand.nextInt(bostonLen));
//            else if(nameChicago.contains(name))
//                bar = chicago.get(rand.nextInt(chicagoLen));
//            else
//                bar = austin.get(rand.nextInt(austinLen));
//            if(counter < numTransactions){
//                //String name = nameStack.peek();
//                tempHash.put("BilliD", String.valueOf(billID));
//                tempHash.put("Drinker", name);
//                tempHash.put("Bar", bar);
//                counter++;
//            }
//            else{
//                counter = 0;
//                billID++;
//                tempHash.put("BilliD", String.valueOf(billID));
//                numTransactions = rand.nextInt(5) + 1;
//                ((LinkedList<String>) nameStack).removeFirst();
//                date = generateDate();
//                tempHash.put("Drinker", name);
//                tempHash.put("Bar", bar);
//            }
//                //tempHash.put("Drinker", );
//            tempHash.put("Date", date);
//            tempHash.put("Time", generateTime());
//            cellOne = currentLine[0].split("=");
//            tempHash.put("TransAction", cellOne[1]);
//            cellTwo = currentLine[3].split("=");
//            tempHash.put("Quantity", cellTwo[1]);
//            System.out.println("Inserting");
//            masterList.add(tempHash);
//        }

        //NEW FREQUENTS
//        ArrayList<String> nyc = new ArrayList<>();
//        ArrayList<String> boston = new ArrayList<>();
//        ArrayList<String> chicago = new ArrayList<>();
//        ArrayList<String> austin = new ArrayList<>();
//        String cityLine;
//        File cityFile = new File("C:\\Users\\Vinh Huynh\\IdeaProjects\\createCSVdata\\src\\" + CITYFILES[0]);
//        BufferedReader cityBuff = new BufferedReader(new FileReader(cityFile));
//        while((cityLine = cityBuff.readLine()) != null)
//            nyc.add(cityLine);
//
//        cityFile = new File("C:\\Users\\Vinh Huynh\\IdeaProjects\\createCSVdata\\src\\" + CITYFILES[1]);
//        cityBuff = new BufferedReader(new FileReader(cityFile));
//        while((cityLine = cityBuff.readLine()) != null)
//            boston.add(cityLine);
//
//        cityFile = new File("C:\\Users\\Vinh Huynh\\IdeaProjects\\createCSVdata\\src\\" + CITYFILES[2]);
//        cityBuff = new BufferedReader(new FileReader(cityFile));
//        while((cityLine = cityBuff.readLine()) != null)
//            chicago.add(cityLine);
//
//        cityFile = new File("C:\\Users\\Vinh Huynh\\IdeaProjects\\createCSVdata\\src\\" + CITYFILES[3]);
//        cityBuff = new BufferedReader(new FileReader(cityFile));
//        while((cityLine = cityBuff.readLine()) != null)
//            austin.add(cityLine);
//
//        File nameFile = new File("C:\\Users\\Vinh Huynh\\IdeaProjects\\createCSVdata\\src\\names.csv");
//        BufferedReader nameBuff = new BufferedReader(new FileReader(nameFile));
//        String city[], name[];
//        int nycLen = nyc.size(), bostonLen = boston.size(), chicagoLen = chicago.size(), austinLen = austin.size(), numBars;
//        Random rand = new Random();
//        while((line = nameBuff.readLine()) != null){
//            LinkedHashMap<String, String> tempHash;// = new LinkedHashMap<>();
//            numBars = rand.nextInt(6);
//            currentLine = line.split(",");
//            city = currentLine[2].split("=");
//            name = currentLine[0].split("=");
//            switch(city[1]){
//                case "New York City":
//                    for(int i = 0; i < numBars; i++){
//                        tempHash = new LinkedHashMap<>();
//                        tempHash.put("Name", name[1]);
//                        tempHash.put("Bar", nyc.get(rand.nextInt(nycLen)));
//
//                        masterList.add(tempHash);
//                    }
//                    break;
//                case "Boston":
//                    for(int i = 0; i < numBars; i++){
//                        tempHash = new LinkedHashMap<>();
//                        tempHash.put("Name", name[1]);
//                        tempHash.put("Bar", boston.get(rand.nextInt(bostonLen)));
//
//                        masterList.add(tempHash);
//                    }
//                    break;
//                case "Chicago":
//                    for(int i = 0; i < numBars; i++){
//                        tempHash = new LinkedHashMap<>();
//                        tempHash.put("Name", name[1]);
//                        tempHash.put("Bar", chicago.get(rand.nextInt(chicagoLen)));
//
//                        masterList.add(tempHash);
//                    }
//                    break;
//                case "Austin":
//                    for(int i = 0; i < numBars; i++){
//                        tempHash = new LinkedHashMap<>();
//                        tempHash.put("Name", name[1]);
//                        tempHash.put("Bar", austin.get(rand.nextInt(austinLen)));
//
//                        masterList.add(tempHash);
//                    }
//                    break;
//            }
//        }
        for(LinkedHashMap<String, String> i : masterList){
            pw.println(i);
            //System.out.println("Line: " + i);
        }
        pw.flush();
        pw.close();
    }
}
