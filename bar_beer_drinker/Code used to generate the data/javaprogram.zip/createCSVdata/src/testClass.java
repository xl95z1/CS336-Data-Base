import java.util.Random;

public class testClass {
    public static void main(String [] args){
        Random rand = new Random();
        int randomNum;
        for(int i = 0; i < 10; i++){
            randomNum = rand.nextInt(2);
            System.out.println("Random Num:" + randomNum);
        }
    }
}
