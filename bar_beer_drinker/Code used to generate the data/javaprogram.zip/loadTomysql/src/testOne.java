public class testOne {
    public static void main(String arg[]){

        System.out.println("A:");
    }
}
